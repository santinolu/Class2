
#include <iostream>

  int main()
 {
    #if DebugConfig
    Console.WriteLine("We are in the debug configuration!");
    #endif
     std::cout<<("This is a toy custom build/installer system\n");
     return 0;
 }
 