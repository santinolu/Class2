
using System;
class HelloWorld
{
 static void Main()
 {
    #if DebugConfig
    Console.WriteLine("We are in the debug configuration!");
    #endif
    Console.WriteLine("This is a toy custom build/installer system");
 }
 }